# 대학생 학술적 글쓰기 인용 방법 가이드 — 안드로이드 앱

웹 가이드(index.html, data.js)를 그대로 담은 오프라인 안드로이드 앱입니다. 인터넷 없이 작동합니다(공식 지침 링크만 브라우저로 열림). 별점·리뷰는 웹 버전에만 있습니다.

## APK 만들기 (GitHub Actions)
1. 이 폴더 전체를 GitHub 저장소에 올립니다(`.github` 폴더 포함).
2. 저장소의 **Actions** 탭 → **Build APK** 실행이 끝나기를 기다립니다(약 5분).
3. 실행 결과 아래 **Artifacts**의 `citation-guide-apk`를 내려받아 압축을 풀면 `app-debug.apk`가 있습니다.
4. 휴대폰에 옮겨 설치합니다(“출처를 알 수 없는 앱 설치” 허용 필요).

## 내용 바꾸기
`app/src/main/assets/www/`의 index.html, data.js를 새 버전으로 바꾸고 `app/build.gradle`의 versionCode를 1 올린 뒤 다시 올리면 됩니다.

본 자료는 학습을 위해 제공된 교육용 자료입니다. © Minseo Seon, All Rights Reserved.
